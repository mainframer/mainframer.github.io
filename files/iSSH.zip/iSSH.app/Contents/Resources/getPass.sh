#!/bin/sh
echo $PASS;